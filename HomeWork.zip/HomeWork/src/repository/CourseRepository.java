package repository;
import exception.NoInputNum;
import jdk.jshell.spi.ExecutionControl;
import model.Course;
import service.CourseService;
import service.CourseServiceImp;

import java.util.*;

public class CourseRepository {
    static List<Course> courses = new ArrayList<>();

    public static void getCourses() {
        CourseService courseService = new CourseServiceImp();
        Random random = new Random();
        String date = courseService.localDate();
        try {
            int arr[] = {0,1,2,3,4,5,6,7,8,9};
            System.out.print("[+] Insert course title: ");
            String title = new Scanner(System.in).nextLine();
            for (int arr1 : arr) {
                if (title.contains(String.valueOf(arr1))) {
                    throw new NoInputNum("Invalid input title: " + title);
                }
            }
            System.out.print("[+] Insert instructor names: ");
            String[] instructor = new Scanner(System.in).nextLine().split(",");
            for (int arr1 : arr) {
                for (String instructor1 : instructor) {
                    if (instructor1.contains(String.valueOf(arr1))) {
                        throw new NoInputNum("Invalid input instructor: " + instructor1);
                    }
                }
            }
            System.out.print("[+] Insert course requirement: ");
            String[] requirement = new Scanner(System.in).nextLine().split(",");
            for (int arr1 : arr) {
                for (String requirement1 : requirement) {
                    if (requirement1.contains(String.valueOf(arr1))) {
                        throw new NoInputNum("Invalid input requirement: " + requirement1);
                    }
                }
            }
            courses.add(new Course(random.nextInt(1000),title,instructor,requirement,date));
        }catch (NoInputNum noInputNum) {
            System.out.println(noInputNum.getMessage());
        }
    }
    public static List<Course> storeCourse() {
        return courses;
    }
}
