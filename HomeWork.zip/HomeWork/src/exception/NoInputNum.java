package exception;

public class NoInputNum extends Exception{
    public NoInputNum() {
        super();
    }
    public NoInputNum(String message) {
        super(message);
    }
}
